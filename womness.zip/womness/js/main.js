jQuery(document).ready(function() {

	jQuery("#cssmenu").menumaker({
		title: "Menu",
		format: "multitoggle"
	});
	
});